# kerala
Admin boundary shapefiles and geojsons for Kerala. Based on datameet.org/maps

## State
![image](https://user-images.githubusercontent.com/371666/44642598-8c888a00-a9ea-11e8-9112-21c239b8ad5a.png)

## District
![image](https://user-images.githubusercontent.com/371666/44642605-97431f00-a9ea-11e8-8b77-09de3b77ab4f.png)

## Taluk
![image](https://user-images.githubusercontent.com/371666/44642610-9d390000-a9ea-11e8-9a83-7ccfa52d3e51.png)

## Village
![image](https://user-images.githubusercontent.com/371666/44642612-a0cc8700-a9ea-11e8-9534-aab0ff58fcb0.png)